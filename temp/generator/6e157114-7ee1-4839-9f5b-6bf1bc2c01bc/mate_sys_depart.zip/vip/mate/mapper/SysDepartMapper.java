package vip.mate.mapper;

import vip.mate.entity.SysDepart;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 组织机构表 Mapper 接口
 * </p>
 *
 * @author pangu
 * @since 2020-07-09
 */
public interface SysDepartMapper extends BaseMapper<SysDepart> {

}
