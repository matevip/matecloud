package vip.mate.system.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import vip.mate.core.web.controller.BaseController;

/**
 * <p>
 * 客户端表 前端控制器
 * </p>
 *
 * @author pangu
 * @since 2020-07-09
 */
@RestController
@RequestMapping("/client")
public class ClientController extends BaseController {

}

