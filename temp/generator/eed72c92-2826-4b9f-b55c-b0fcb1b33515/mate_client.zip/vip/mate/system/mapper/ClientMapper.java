package vip.mate.system.mapper;

import vip.mate.system.entity.Client;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 客户端表 Mapper 接口
 * </p>
 *
 * @author pangu
 * @since 2020-07-09
 */
public interface ClientMapper extends BaseMapper<Client> {

}
