package vip.mate.controller;


import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;
import vip.mate.core.web.controller.BaseController;

/**
 * <p>
 * 字典表 前端控制器
 * </p>
 *
 * @author pangu
 * @since 2020-07-09
 */
@RestController
@RequestMapping("/sys-dict")
public class SysDictController extends BaseController {

}

