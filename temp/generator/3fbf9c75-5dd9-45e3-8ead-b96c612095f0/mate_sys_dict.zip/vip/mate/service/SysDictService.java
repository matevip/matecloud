package vip.mate.service;

import vip.mate.entity.SysDict;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 字典表 服务类
 * </p>
 *
 * @author pangu
 * @since 2020-07-09
 */
public interface SysDictService extends IService<SysDict> {

}
